export const MODULE_NAME = "summoner-class-for-5e";
